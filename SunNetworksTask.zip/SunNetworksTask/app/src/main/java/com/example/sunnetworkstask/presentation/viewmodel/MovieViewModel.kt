package com.example.sunnetworkstask.presentation.viewmodel

import androidx.lifecycle.ViewModel
import com.example.sunnetworkstask.domain.model.Movie
import com.example.sunnetworkstask.domain.usecase.GetCarouselsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class MovieViewModel @Inject constructor(
    private val useCase: GetCarouselsUseCase
) : ViewModel() {
    private val _carousels = MutableStateFlow<Map<String, List<Movie>>>(emptyMap())
    val carousels: StateFlow<Map<String, List<Movie>>> = _carousels

    init {
        _carousels.value = useCase()
    }
}
