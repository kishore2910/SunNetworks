package com.example.sunnetworkstask.domain.usecase

import com.example.sunnetworkstask.data.repository.MovieRepository
import com.example.sunnetworkstask.domain.model.Movie


class GetCarouselsUseCase(private val repository: MovieRepository) {
    operator fun invoke(): Map<String, List<Movie>> = repository.getCarousels()
}