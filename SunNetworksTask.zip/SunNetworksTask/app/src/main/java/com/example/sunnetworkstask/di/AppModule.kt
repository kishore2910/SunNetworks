package com.example.sunnetworkstask.di

import com.example.sunnetworkstask.data.repository.MovieRepository
import com.example.sunnetworkstask.domain.usecase.GetCarouselsUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    fun provideFakeMovieRepository() = MovieRepository()

    @Provides
    fun provideGetCarouselsUseCase(repo: MovieRepository) = GetCarouselsUseCase(repo)
}