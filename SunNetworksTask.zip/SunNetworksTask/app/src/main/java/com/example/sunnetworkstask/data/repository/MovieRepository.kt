package com.example.sunnetworkstask.data.repository

import com.example.sunnetworkstask.domain.model.Movie
import kotlin.random.Random

class MovieRepository {
    fun getCarousels(): Map<String, List<Movie>> {
        return mapOf(
            "Trending Now" to generateMovies(),
            "Watch Again" to generateMovies(),
            "Top 10 in India" to generateMoviesTwo(),
            "Popular Shows" to generateMoviesTwo(),
            "Hall Of Fame" to  generateMoviesThree(),
            "Popular in Action" to generateMoviesThree(),
            "Today's Special" to generateMovies(),
            "Exclusive Entertainment" to generateMoviesThree(),
            "Recommended For You" to generateMoviesThree(),
            "Inspirational Shows" to generateMoviesTwo()
        )
    }

    private fun generateMovies(): List<Movie> {
        return List(15) {
            Movie(
                id = "$it",
                title = "Movie $it",
                thumbnailUrl = "https://picsum.photos/200/300?random=${Random.nextInt(1, 1000)}",
                videoUrl = "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4"
            )
        }
    }

    private fun generateMoviesTwo() : List<Movie> {
        return List(10) {
            Movie(
                id = "$it",
                title = "Movie $it",
                thumbnailUrl = "https://picsum.photos/200/300?random=${Random.nextInt(1, 1000)}",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
            )
        }
    }

    private fun generateMoviesThree() : List<Movie> {
        return List(10) {
            Movie(
                id = "$it",
                title = "Movie $it",
                thumbnailUrl = "https://picsum.photos/200/300?random=${Random.nextInt(1, 1000)}",
                videoUrl = "https://archive.org/download/ElephantsDream/ed_1024_512kb.mp4"
            )
        }
    }
}